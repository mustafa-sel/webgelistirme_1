import getData from "./app.js"

console.log(getData(1));